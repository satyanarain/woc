/*
 * @author satya
 * created password  2 Aug 2018
 * Modified  19 November 2018
 * This is page for Request Form Appointment
 */
 // import { createStore, applyMiddleware } from 'redux';
 // import { Provider } from 'react-redux';
 // import { apiMiddleware, reducer } from './redux';

// const store = createStore(reducer, {}, applyMiddleware(apiMiddleware));
// store.dispatch({type: 'GET_MOVIE_DATA'});
// class LanguageVariableList extends React.Component {
//   static LOGIN_HEADER = '';
//   static LOGIN_EMAIL_HINT = '';
//   static LOGIN_PASSWORD_HINT = '';
//   static LOGIN_BUTTON_SIGN_IN = '';
//   static LOGIN_BUTTON_SIGN_UP = '';
//   static LOGIN_FORGOT_PASSWORD = '';
//   static LOGIN_EMAIL_ERROR = '';
//   static LOGIN_PASSWORD_ERROR = '';
//
//
// }
//
//  export default LanguageVariableList;
